# zno_al
zno_al
Quantum Espresso
